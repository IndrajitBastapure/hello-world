package com.tm.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.tm.spring.pojo.Contact;

@Controller
@SessionAttributes
public class HelloWorldController {

	@RequestMapping("/hello")
	public ModelAndView sayHello(){
		
		String msg = "Hello ! Spring..";
		
		return new ModelAndView("hellomsg","command",msg);
	}
	  
	    @RequestMapping(value = "/addContact", method = RequestMethod.POST)  
	    public String addContact(@ModelAttribute("contact") Contact contact, BindingResult result,Model model,
	    		String firstname,String lastname,String email,String telephone ) {  
	    	model.addAttribute("firstname", firstname);
	    	model.addAttribute("lastname", lastname);
	    	model.addAttribute("email", email);
	    	model.addAttribute("telephone", telephone);
	        return "contactinfo";  
	    }  
	
	@RequestMapping("/contact")
	public ModelAndView contactForm(){
		
		return new ModelAndView("contact", "command", new Contact()); 
	}

}
