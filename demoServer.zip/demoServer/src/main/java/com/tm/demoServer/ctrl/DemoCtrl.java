package com.tm.demoServer.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tm.demoServer.model.Person;
import com.tm.demoServer.service.PersonService;

@RestController
public class DemoCtrl {
	
	@Autowired
	PersonService personService;

	@RequestMapping(value="/getAllPersons",method=RequestMethod.GET)
	public List<Person> getMethod() {
		
		return personService.getAllPersons();
	}
	
	@RequestMapping(value="/getPerson/{id}",method=RequestMethod.GET)
	public Person getPersonMethod(@PathVariable Integer id) {
		
		return personService.getPerson(id);
	}
	
	@RequestMapping(value="/addPerson",method=RequestMethod.POST)
	public void putMethod(@RequestBody Person person) {
		
		personService.addPerson(person);
	}
}
