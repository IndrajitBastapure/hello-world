package com.tm.demoServer.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.tm.demoServer.model.Person;

@Service
public class PersonService {

	public static List<Person> persons;
	
	static {
		persons = getPersons();
	}
	
	public List<Person> getAllPersons() {
		return persons;
	}
	
	public Person getPerson(Integer id) {
		
		for(Person per : persons) {
			if(per.getId() == id) {
				return per;
			}
		}
		return null;
	}
	
	public void addPerson(Person person) {
		persons.add(person);
	}
	
	
	
	public static List<Person> getPersons(){
		
		System.out.println("Inside getPersons()..");
		List<Person> persons = new ArrayList<>();
		
		Person p1 = new Person();
		p1.setId(100);
		p1.setFname("Michel");
		p1.setLname("Scofield");
		p1.setCity("Las Vegas");
		p1.setCountry("USA");
		
		Person p2 = new Person();
		p2.setId(101);
		p2.setFname("Sara");
		p2.setLname("Tancredi");
		p2.setCity("Copenhagen");
		p2.setCountry("Denmark");
		
		persons.add(p1);
		persons.add(p2);
		
		System.out.println("List : "+persons);
		return persons;
	}
	
}
