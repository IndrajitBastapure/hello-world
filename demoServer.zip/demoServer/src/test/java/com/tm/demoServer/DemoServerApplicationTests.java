package com.tm.demoServer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(
		webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT
		)
public class DemoServerApplicationTests {

	private TestRestTemplate testRestTemplate;
	
	public DemoServerApplicationTests() {
		testRestTemplate = new TestRestTemplate();
	}
	
	@Test
	public void testPersonById() {
		
		ResponseEntity<String> resp = testRestTemplate.getForEntity("http://localhost:8084/getPerson/101", String.class);
		System.out.println("Response : "+resp);
		assertThat(resp.getStatusCode(), equalTo(HttpStatus.OK));
	}

}
