package com.tm.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;


@Controller
@SessionAttributes
public class HelloWorldController {

	@RequestMapping("/welcome")
	public String printWelcome(ModelMap model){
		
		model.addAttribute("msg", "Hello, Welcome to the world of Spring Security..");
		
		return "welcome";
	}
}
