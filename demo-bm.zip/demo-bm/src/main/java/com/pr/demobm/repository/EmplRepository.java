package com.pr.demobm.repository;

import org.springframework.data.repository.CrudRepository;

import com.pr.demobm.model.Employee;

public interface EmplRepository extends CrudRepository<Employee, Long>{

}
