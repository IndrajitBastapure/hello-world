package com.pr.demobm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pr.demobm.model.Employee;
import com.pr.demobm.repository.EmplRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmplRepository emplRepository;

	public void addEmployee(Employee emp){
		emplRepository.save(emp);
	}
	public Employee getEmployee(Long id){
		return emplRepository.findOne(id);
	}
	public void updateEmployee(Long id,Employee emp){
		if(emplRepository.exists(id)){
			emplRepository.save(emp);
		}
	}
	public void deleteEmployee(Long id){
		emplRepository.findOne(id);
	}
}
