package com.pr.demobm.ctrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.pr.demobm.model.Employee;
import com.pr.demobm.service.EmployeeService;

@RestController
public class EmployeeCtrl {

	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping(value="/getEmployee/{id}" ,method = RequestMethod.GET)
	public Employee getEmployee(@PathVariable("id") Long id){
		return employeeService.getEmployee(id);
	}
	
	@RequestMapping(value="/addEmployee" ,method = RequestMethod.POST)
	public void addEmployee(@RequestBody Employee emp){
		employeeService.addEmployee(emp);
	}
	
	@RequestMapping(value="/updateEmployee/{id}" ,method = RequestMethod.PUT)
	public void updateEmployee(@PathVariable("id") Long id,@RequestBody Employee emp){
		employeeService.updateEmployee(id, emp);
	}

	@RequestMapping(value="/deleteEmployee/{id}" ,method = RequestMethod.DELETE)
	public void deleteEmployee(Long id){
		employeeService.deleteEmployee(id);
	}
}
