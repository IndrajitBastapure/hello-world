package com.pr.demobm.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name= "Employee")
public class Employee {

	@JsonProperty("empId")
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long empId;
	@JsonProperty("empName")
	private String empName;
	@JsonProperty("empCity")
	private String empCity;
	
	public Employee() {
	}
	
	public Employee(Long empId, String empName, String empCity) {
		this.empId = empId;
		this.empName = empName;
		this.empCity = empCity;
	}
	public Long getEmpId() {
		return empId;
	}
	public void setEmpId(Long empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpCity() {
		return empCity;
	}
	public void setEmpCity(String empCity) {
		this.empCity = empCity;
	}
}
